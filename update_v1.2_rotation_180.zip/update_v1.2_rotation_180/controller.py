import pymssql, os, json, platform, cv2, numpy as np
import sys, logging, urllib.request, zipfile, shutil
from datetime import datetime
from PyQt5.QtCore import QObject, pyqtSignal
from ctypes import c_char
from fsdk import FSDK
from nano import Nano

DIR_NAME = "."
plform = sys.platform
if 'linux' in plform:
    DIR_NAME = os.path.dirname(os.path.abspath(__file__))
#print(DIR_NAME)
#print(type(DIR_NAME))

MACHINE_NAME = platform.uname()[1]
print(MACHINE_NAME)

CAMERA_INDEX = 0
FRAME_WIDTH = 640
FRAME_HEIGHT = 480
FSDK_FACE_TEMPLATE_SIZE = 1024 + 4*4
DATA_FILE_PATH = f"{DIR_NAME}/data/data.json"
SETTING_FILE_PATH = f"{DIR_NAME}/data/setting.json"
EMPLOYEE_FILE_PATH = f"{DIR_NAME}/data/employee.json"
FD_MARKS_FILE_PATH = f"{DIR_NAME}/fd_masks1.bin"
EVIDENCE_FOLDER_PATH = f"{DIR_NAME}/evidence"
LOGS_FILE_PATH = f"{DIR_NAME}/logs/failed_data.txt"
ACCESS_DOOR_SOUND = f"{DIR_NAME}/access-door.wav"

DB_SERVER = "10.64.8.150"
DB_USER = "Face"
DB_PASSWORD = "u3v*m@pN"
DB_NAME = "FaceRecognition"

# DB_SERVER = "10.64.4.63"
# DB_USER = "sa"
# DB_PASSWORD = "123456"
# DB_NAME = "FaceRecognition"

ESD_DB_SERVER = "10.64.8.150"
ESD_DB_NAME = "ESD_Control"
ESD_DB_USER = "vtnadmin"
ESD_DB_PASSWORD = "ZAQ!xsw2"

FACE_LIST = []
FACE_LIST_JSON = []
DEVICE_SETTING = []
LICENSE_KEY = "LImcnZzkzw8RrawhS1F1kirLGcLBEC5xWkpNWBFXCnSiOYEzzcbTSJ0M5NqD7e6Ai7KCJi4g63nKFPVyxhRHq0vwGN/d+bqXummVuocUNIzUO6EWAhlMUv/dtztWSAMNzi0RjrZm0XOJzq0ukos9ZQT4L+aiGm1mKjDEKuPETBk="

QUERY_FACE_LIST = f"SELECT [Code],[Fullname],[Template],[SimilarThreshold],[ID],[Group],[HasFaceMask] FROM [FaceList] ORDER BY [CreatedDate] DESC"
QUERY_DEVICE_SETTING = f"SELECT TOP 1 [MachineName],[MachineType],[Location],[Server],[Database],[Username],[Password],[DatabaseTimeout],[DoorTimeout],[InOutMode],[AdminUsers],[AllowFaceMask],[AllowGroup],[SmilePassed],[UseEmoji],[NeedToUpdate],[LinkToUpdate],[Status],[SoftwareVersion],[LastestUpdateVersion],[LastestUpdateDB] FROM [DeviceList] WHERE MachineName='{MACHINE_NAME}'"
QUERY_GET_EMPLOYEE_LIST = """SELECT E.EmployeeATID AS EmployeeCode, E.LastName + ' ' + IIF(LEN(E.MidName) > 0, E.MidName + ' ', '') + E.FirstName AS 'EmployeeName', E.NickName, 
                                cast(cast(E.YearOfBirth * 10000 + E.MonthOfBirth * 100 + E.DayOfBirth AS varchar(255)) AS date) AS [DateOfBirth], P.Name AS Position, D .Name AS Department
                        FROM abriDBHRPro7_Ver3_SPARTON.dbo.HR_Employee AS E INNER JOIN
                                abriDBHRPro7_Ver3_SPARTON.dbo.HR_WorkingInfo AS W ON E.EmployeeATID = W.EmployeeATID INNER JOIN
                                abriDBHRPro7_Ver3_SPARTON.dbo.HR_Position AS P ON W.PositionIndex = P.[Index] INNER JOIN
                                abriDBHRPro7_Ver3_SPARTON.dbo.HR_Department AS D ON W.DepartmentIndex = D .[Index]
                        WHERE W.ToDate IS NULL AND NOT EXISTS(SELECT EmployeeATID FROM abriDBHRPro7_Ver3_SPARTON.dbo.HR_EmployeeStoppedWorkingInfo WHERE EmployeeATID = E.EmployeeCode)"""
QUERY_GET_ESD_ACCESS_LIST = "SELECT id_card, name FROM dbo.AcceptedCard"
QUERY_INSERT_ESD_RECORD = "INSERT INTO Record (username, fullname, date, type, duration, result, machine) VALUES (%s, %s, %s, %s, %s, %s, %s)"

FILE_PATH_TO_UPDATE = './downloaded/version'
FOLDER_NAME_TO_UPDATE = './downloaded/updated/'

IN_MODE = 1
OUT_MODE = 2
IN_OUT_MODE = 1
DURATION_INSERT = 300


class FacePos():
    width = 0
    height = 0
    left = 0
    top = 0

class DeviceSetting():
    MachineName = ""
    MachineType = ""
    Location = ""
    Server = ""
    Database = ""
    Username = ""
    Password = ""
    FaceServer = ""
    FaceDatabase = ""
    FaceUsername = ""
    FacePassword = ""
    DatabaseTimeout = 3
    DoorTimeout = 5
    InOutMode = False
    AdminUsers = ""
    AllowFaceMask = False
    AllowGroup = ""
    SmilePassed = 0
    UseEmoji = False
    NeedToUpdate = False
    LinkToUpdate = ""
    Status = False
    SoftwareVersion = ""
    LastestUpdateVersion = datetime.now()
    LastestUpdateDB = datetime.now()

class Employee():
    EmployeeCode = ""
    EmployeeName = ""
    NickName = ""
    DateOfBirth = ""
    Position = ""
    Department = ""

device_Settings = DeviceSetting()


class FaceProccess(object):
    def Go_Search_Face(facetemplate,facelist):
        try:
            smltmp = 0
            similarity = 0
            ress = ""
            ress2 = ""
            for face in facelist:
                #print(face["Template"])
                #print(type(face["Template"]))
                face_item = bytes(face["Template"], "latin1")
                item = (c_char*FSDK_FACE_TEMPLATE_SIZE).from_buffer(bytearray(face_item))
                smltmp = FSDK.MatchFaces(facetemplate, item)
                #print(smltmp)
                if smltmp > face["SimilarThreshold"]:
                    if(similarity < smltmp):
                        similarity = smltmp
                        ress = f'{face["Code"]}-{face["Fullname"]}'
                        ress2 = f'{face["ID"]}-{face["HasFaceMask"]}-{face["Group"]}'

            return [similarity, f"{ress}-{similarity}-{ress2}"]
        except Exception as ex:
            print(f"Go_Search_Face: {ex}")
            error_log.exception(ex, exc_info=True)

    def Load_Face_List(self):
        rsFaceList = []
        appCtrl = AppController()
        try:
            # Connect to server
            self.conn = pymssql.connect(server=DB_SERVER, user=DB_USER, password=DB_PASSWORD, database=DB_NAME, login_timeout=device_Settings.DatabaseTimeout, timeout=device_Settings.DatabaseTimeout)
            self.cursor = self.conn.cursor(as_dict=True)
            self.cursor.execute(QUERY_FACE_LIST)
            for item in self.cursor:
                rsFaceList.append(item)
            self.cursor.close()
            self.conn.close()

            # Update Lastest Updated DB Time
            self.update_time = datetime.now().strftime('%Y/%m/%d %H:%M:%S')
            self.query_update = f"UPDATE [DeviceList] SET [LastestUpdateDB] = '{self.update_time}' WHERE [MachineName]='{MACHINE_NAME}'"
            self.conn = pymssql.connect(server=DB_SERVER, user=DB_USER, password=DB_PASSWORD, database=DB_NAME, login_timeout=device_Settings.DatabaseTimeout, timeout=device_Settings.DatabaseTimeout)
            self.cursor = self.conn.cursor()
            self.cursor.execute(self.query_update)
            self.conn.commit()
            self.cursor.close()
            self.conn.close()

            print("Loaded data from Database.")
            appCtrl.WriteDataToJsonFile(rsFaceList)
        except Exception as ex:
            #print(f"Load_Face_List: {ex}")
            print("Loaded data from local file.")
            # Load data from Json backup file before when disconnected to server
            with open(DATA_FILE_PATH, "r") as f:
                data = json.load(f)
                for item in data:
                    rsFaceList.append(item)

        return rsFaceList

    def Load_Device_Setting(self):
        self.rsDeviceSetting = []
        appCtrl = AppController()
        try:
            self.conn = pymssql.connect(server=DB_SERVER, user=DB_USER, password=DB_PASSWORD, database=DB_NAME, login_timeout=device_Settings.DatabaseTimeout, timeout=device_Settings.DatabaseTimeout)
            self.cursor = self.conn.cursor(as_dict=True)
            self.cursor.execute(QUERY_DEVICE_SETTING)
            for item in self.cursor:
                self.rsDeviceSetting.append(item)
            
            self.cursor.close()
            self.conn.close()

            print("Loaded Setting from database.")
            appCtrl.WriteToJsonFile(self.rsDeviceSetting, SETTING_FILE_PATH)
        except Exception as ex:
            #print(f"Load_Device_Setting: {ex}")
            print("Loaded Setting from local file.")
            with open(SETTING_FILE_PATH, "r") as f:
                self.data = json.load(f)
                for item in self.data:
                    self.rsDeviceSetting.append(item)
        return self.rsDeviceSetting

class AppController(object):
    allow_insert = False
    inserted_list = []

    def WriteDataToJsonFile(self,facelist):
        try:
            # Write data into local json backup file
            if(len(facelist) > 0):
                FACE_LIST_JSON = []
                for f in facelist:
                    f["Template"] = str(f["Template"], "latin1")
                    FACE_LIST_JSON.append(f)

                self.f = open(DATA_FILE_PATH, "w")
                self.json_string = json.dumps(FACE_LIST_JSON, indent=2, default=str)
                self.f.write(self.json_string)
                self.f.close()
            print("Wrote data to local file.")
        except Exception as ex:
            print(f"WriteDataToJsonFile: {ex}")
            error_log.exception(f"WriteDataToJsonFile: {ex}", exc_info=True) 

    def WriteToJsonFile(self, data, file_path):
        try:
            self.f = open(file_path, "w")
            self.json_string = json.dumps(data, indent=2, default=str)
            self.f.write(self.json_string)
            self.f.close()
            print("Wrote setting to local file.")
        except Exception as ex:
            print(f"WriteToJsonFile: {ex}")
            error_log.exception(f"WriteDataToJsonFile: {ex}", exc_info=True)

    def SaveEvidence(self,frame,code,name):
        #print("Saving evidence...")
        try:
            dirname = os.path.dirname(f"{EVIDENCE_FOLDER_PATH}/{str(datetime.now().month)}/{str(datetime.now().day)}/")
            if len(dirname) > 0 and not os.path.exists(dirname):
                os.makedirs(dirname)
            filename = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{code}_{name}.jpg"
            cv2.imwrite(dirname + "/" + filename,frame)
            print("Saved evidence to: " + dirname + "/" + filename)
        except Exception as ex:
            print(f"SaveEvidence: {ex}")
            error_log.exception(f"SaveEvidence: {ex}", exc_info=True)

    def CompareTime(self,beginTime,endTime):
        self.rsTime = datetime.timestamp(endTime) - datetime.timestamp(beginTime)
        return self.rsTime

    def Save_User_Logs_File(self, code, fullname, date, type, duration, result, machine):
        try:
            data = f"{code},{fullname},{date},{type},{duration},{result},{machine}\n"
            f = open(LOGS_FILE_PATH, 'a')
            f.write(data)
            f.close()
        except Exception as ex:
            print(f"Save_User_Logs_File: {ex}")
            error_log.exception(ex, exc_info=True)

    def Sync_User_Data_Failed(self):
        self.synced_record = 0
        try:
            f = open(LOGS_FILE_PATH, 'r')
            self.logs_list = f.readlines()
            f.close()

            if len(self.logs_list) > 0:
                self.conn = pymssql.connect(server=ESD_DB_SERVER, user=ESD_DB_USER, password=ESD_DB_PASSWORD, database=ESD_DB_NAME, login_timeout=device_Settings.DatabaseTimeout, timeout=device_Settings.DatabaseTimeout)
                self.cursor = self.conn.cursor()
                self.timeupdate = datetime.now().strftime('%Y/%m/%d %H:%M:%S')
                query = QUERY_INSERT_ESD_RECORD
                write_data = tuple(tuple(line.strip().split(',')) for line in self.logs_list)
                #print(write_data)
                self.cursor.executemany(query, write_data)
                self.conn.commit()
                self.cursor.close()
                self.conn.close()
                self.synced_record = len(self.logs_list)
                print("Sync User Data Success.")

                # Truncate logs file
                f = open(LOGS_FILE_PATH, 'r+')
                f.truncate()
                f.close()
        except Exception as ex:
            print(f"Sync_User_Data_Failed: {ex}")
            error_log.exception(f"Sync_User_Data_Failed: {ex}", exc_info=True)
        return self.synced_record

    def SetupLog(log_name, file_name, level=logging.INFO):
        try:
            dirname = os.path.dirname(file_name)
            if len(dirname) > 0 and not os.path.exists(dirname):
                os.makedirs(dirname)
            handler = logging.FileHandler(file_name, 'a', 'utf-8')
            handler.setFormatter(logging.Formatter('%(asctime)s : %(levelname)-8s - %(message)s'))
            logger = logging.getLogger(log_name)
            logger.setLevel(level)
            logger.addHandler(handler)
            return logger
        except Exception as ex:
            print(f"SetupLog: {ex}")
            error_log.exception(f"SetupLog: {ex}", exc_info=True)

    def UpdateSoftware(self):
        try:
            if device_Settings.NeedToUpdate == True:
                # Download zip file from Link
                self.dlfile = urllib.request.urlopen(device_Settings.LinkToUpdate)
                self.dlfile_path = FILE_PATH_TO_UPDATE + f"_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
                with open(self.dlfile_path,'wb') as output:
                    output.write(self.dlfile.read())

                # Extract and move all file to update
                self.ExtractZipFile(self.dlfile_path,FOLDER_NAME_TO_UPDATE)
                self.MoveAllFileToFolder(FOLDER_NAME_TO_UPDATE, './')

                # Update SoftwareVersion, LastestUpdateVersion, NeedToUpdate
                self.update_time = datetime.now().strftime('%Y/%m/%d %H:%M:%S')
                self.query_update = f"UPDATE [DeviceList] SET [LastestUpdateVersion] = '{self.update_time}', [NeedToUpdate] = 0 WHERE MachineName='{MACHINE_NAME}'"
                self.conn = pymssql.connect(server=DB_SERVER, user=DB_USER, password=DB_PASSWORD, database=DB_NAME, login_timeout=device_Settings.DatabaseTimeout, timeout=device_Settings.DatabaseTimeout)
                self.cursor = self.conn.cursor()
                self.cursor.execute(self.query_update)
                self.conn.commit()
                self.cursor.close()
                self.conn.close()
                return True
            else:
                return False
        except Exception as ex:
            print(f"UpdateSoftware: {ex}")
            error_log.exception(f"UpdateSoftware: {ex}", exc_info=True)
            return False

    def MoveAllFileToFolder(self,source_folder,destination_folder):
        try:
            # fetch all files
            for file_name in os.listdir(source_folder):
                #print(file_name)
                # construct full file path
                self.source = source_folder + file_name
                self.destination = destination_folder + file_name
                if os.path.isfile(self.source):
                    shutil.move(self.source, self.destination)
                    print('Moved:', file_name)
        except Exception as ex:
            print(f"MoveAllFileToFolder {ex}")
            error_log.exception(f"MoveAllFileToFolder {ex}", exc_info=True)

    def ExtractZipFile(self,zip_file_path,directory_extract_to):
        try:
            with zipfile.ZipFile(zip_file_path,'r') as zip_ref:
                zip_ref.extractall(directory_extract_to)
        except Exception as ex:
            print(f"ExtractZipFile {ex}")
            error_log.exception(f"ExtractZipFile {ex}", exc_info=True)

    def InsertToESD(self, code, fullname, type, duration, result):
        try:
            update_time = datetime.now().strftime('%Y/%m/%d %H:%M:%S')
            query = QUERY_INSERT_ESD_RECORD
            payload = (code, fullname, update_time, type, duration, result, device_Settings.Location)
            # Connect to server
            self.conn = pymssql.connect(server=ESD_DB_SERVER, user=ESD_DB_USER, password=ESD_DB_PASSWORD, database=ESD_DB_NAME, login_timeout=device_Settings.DatabaseTimeout, timeout=device_Settings.DatabaseTimeout)
            self.cursor = self.conn.cursor()
            self.cursor.execute(query, payload)
            self.conn.commit()
            self.cursor.close()
            self.conn.close()
        except Exception as ex:
            print(f"Insert failed to database. Save to log file!")
            self.Save_User_Logs_File(code, fullname, update_time, type, duration, result, device_Settings.Location)
            error_log.exception(f"InsertToESD: {ex}", exc_info=True)

    def InsertToTA_LogTime(self, code, mode):
        try:
            self.update_time = datetime.now().strftime('%Y/%m/%d %H:%M:%S')
            self.QUERY_INSERT_LOGTIME = f"INSERT INTO TA_TimeLog (EmployeeATID, Time, MachineSerial, InOutMode, SpecifiedMode, Action, UpdatedDate, UpdatedUser, CompanyIndex) VALUES ('{code}', '{self.update_time}', '{MACHINE_NAME}', {mode}, 0, 'ADD', '{self.update_time}', '', 1)"
            #print(self.QUERY_INSERT_LOGTIME)
            # Connect to server
            self.conn = pymssql.connect(server=device_Settings.Server, user=device_Settings.Username, password=device_Settings.Password, database=device_Settings.Database, login_timeout=device_Settings.DatabaseTimeout, timeout=device_Settings.DatabaseTimeout)
            self.cursor = self.conn.cursor()
            self.cursor.execute(self.QUERY_INSERT_LOGTIME)
            self.conn.commit()
            self.cursor.close()
            self.conn.close()

            # Remove existed item and then append new item 
            if len(self.inserted_list) > 0:
                for item in self.inserted_list:
                    if item[0] == code:
                        self.inserted_list.remove(item)
            self.inserted_list.append([code,datetime.now()])
        except Exception as ex:
            self.Save_User_Logs_File(code, mode)
            print(f"InsertToTA_LogTime: {ex}")
            error_log.exception(f"InsertToTA_LogTime: {ex}", exc_info=True)

    def SaveLogsToFaceDB(self, message, type):
        try:
            self.update_time = datetime.now().strftime('%Y/%m/%d %H:%M:%S')
            self.query_logs = f"INSERT INTO [Logs]([Message], [Type], [CreatedDate]) VALUES('{message}', '{type}', '{self.update_time}')"
            self.conn = pymssql.connect(server=device_Settings.Server, user=device_Settings.Username, password=device_Settings.Password, database=device_Settings.Database, login_timeout=device_Settings.DatabaseTimeout, timeout=device_Settings.DatabaseTimeout)
            self.cursor = self.conn.cursor()
            self.cursor.execute(self.query_logs)
            self.conn.commit()
            self.cursor.close()
            self.conn.close()
        except Exception as ex:
            print(f"SaveLogsToFaceDB: {ex}")
            error_log.exception(f"SaveLogsToFaceDB: {ex}", exc_info=True)

    def CheckAllowInsert(self, code):
        #print(f"Checking: {self.inserted_list}")
        if len(self.inserted_list) > 0:
            for item in self.inserted_list:
                if item[0] == code and self.CompareTime(item[1], datetime.now()) <= DURATION_INSERT:
                    return False
            return True
        else:
            return True

    def CheckGroupPermission(self, group):
        self.allowGroups = device_Settings.AllowGroup.split(";")
        if any(item in group for item in self.allowGroups):
            return True
        return False

class FaceSearch(QObject):
    finished = pyqtSignal()
    progress = pyqtSignal(str)
    filename = None
    running = True
    is_new = False
    appCrtrl = AppController()

    def set_filename(self, filename):
        self.filename = filename
        self.is_new = True

    def send_frame(self, frm):
        self.frame = frm
        self.is_new = True

    def run(self):
        self.ll = 0
        self.tt = 0
        self.ww = 0
        self.hh = 0
        while self.running:
            try:
                if self.is_new:
                    
                    height, width, channel = self.frame.shape
                    buffer = self.frame.tobytes()
                    img = FSDK.LoadImageFromBuffer(buffer, width, height, channel*width, FSDK.FSDK_IMAGE_COLOR_24BIT)

                    fp = FSDK.DetectFace(img)
                    facialFeatures = FSDK.DetectFacialFeatures(img)
                    #print(facialFeatures)
                    facialAttributeValues = FSDK.DetectFacialAttributeUsingFeatures(img, facialFeatures, "Expression")
                    #print(facialAttributeValues)
                    self.smileAtt = FSDK.GetValueConfidence(facialAttributeValues, "Smile")
                    self.smilePercent = int(self.smileAtt * 100)
                    #print(self.smileAtt)

                    face_template = FSDK.GetFaceTemplateInRegion(img, fp)
                    #print(f"Face searching...{len(FACE_LIST)}")
                    rs = FaceProccess.Go_Search_Face(face_template, FACE_LIST)
                    if float(rs[0]) > 0:
                        self.rsCodeName = rs[1].split('-')
                        self.code = self.rsCodeName[0]
                        self.name = self.rsCodeName[1]
                        self.similarity = self.rsCodeName[2]
                        self.faceid = self.rsCodeName[3]
                        self.hasfacemask = self.rsCodeName[4]
                        self.group = self.rsCodeName[5]
                        #print(self.rsCodeName)

                        # Check Group Permission of this machine
                        self.allow_permission = self.appCrtrl.CheckGroupPermission(self.group)
                        # if self.allow_permission == True:
                        #     # Check already inserted duration in 300 seconds
                        #     self.allow_insert = self.appCrtrl.CheckAllowInsert(self.code)
                        #     if self.allow_insert:
                        #         try:
                        #             print("Save log and evidence.")
                        #             # Insert into HR DB
                        #             self.appCrtrl.InsertToTA_LogTime(self.code,IN_OUT_MODE)
                        #             # Save logs in FR DB
                        #             self.now_time = datetime.now().strftime('%Y/%m/%d %H:%M:%S')
                        #             self.message = f"[{MACHINE_NAME}] Inserted data for {self.name} (Code: {self.code}, Date: {self.now_time}, inout: {IN_OUT_MODE}) [Similarity: {self.similarity}] [FaceID: {self.faceid}] [HasFaceMask: {self.hasfacemask}]"
                        #             self.appCrtrl.SaveLogsToFaceDB(self.message, "Info")
                        #         except Exception as e:
                        #             print(f"Save log failed: {e}")
                        #             error_log.exception(e, exc_info=True)
                        #             # Save logs into local file
                        #             self.appCrtrl.Save_User_Logs_File(self.code,IN_OUT_MODE)
                        #         # Save evidence
                        #         self.appCrtrl.SaveEvidence(self.frame,self.code,self.name)

                        self.progress.emit(f"{rs[1]}-{self.allow_permission}-{self.smilePercent}-{width}-{height}")

                    self.is_new = False
                    self.ll = fp.xc - int(fp.w * 0.5)
                    self.tt = fp.yc - int(fp.w * 0.5)
                    self.ww = int(fp.w * 0.95)
                    self.hh = int(fp.w * 1.05)
            except Exception as ex:
                #print(ex)
                self.ll = 0
                self.tt = 0
                self.ww = 0
                self.hh = 0
                pass
        self.finished.emit()

class DataFileController(QObject):
    finished = pyqtSignal()
    progress = pyqtSignal(str)
    def ReloadDataFile(self):
        self.facepro = FaceProccess()
        FACE_LIST = self.facepro.Load_Face_List()
        print(f"### Reloaded data: {len(FACE_LIST)}", datetime.now())
        self.finished.emit()

class SettingFileController(QObject):
    finished = pyqtSignal()
    progress = pyqtSignal(str)
    def ReloadSettingFile(self):
        self.facepro = FaceProccess()
        DEVICE_SETTING = self.facepro.Load_Device_Setting()
        if len(DEVICE_SETTING) > 0:
            device_Settings.LinkToUpdate = DEVICE_SETTING[0]["LinkToUpdate"]
            device_Settings.NeedToUpdate = DEVICE_SETTING[0]["NeedToUpdate"]
            device_Settings.AllowFaceMask = DEVICE_SETTING[0]["AllowFaceMask"]
            device_Settings.AllowGroup = DEVICE_SETTING[0]["AllowGroup"]
            device_Settings.AdminUsers = DEVICE_SETTING[0]["AdminUsers"]
            device_Settings.DatabaseTimeout = DEVICE_SETTING[0]["DatabaseTimeout"]
            device_Settings.DoorTimeout = DEVICE_SETTING[0]["DoorTimeout"]
            device_Settings.Server = DEVICE_SETTING[0]["Server"]
            device_Settings.Database = DEVICE_SETTING[0]["Database"]
            device_Settings.Username = DEVICE_SETTING[0]["Username"]
            device_Settings.Password = DEVICE_SETTING[0]["Password"]
            device_Settings.UseEmoji = DEVICE_SETTING[0]["UseEmoji"]
            device_Settings.SmilePassed = DEVICE_SETTING[0]["SmilePassed"]
            device_Settings.SoftwareVersion = DEVICE_SETTING[0]["SoftwareVersion"]
            device_Settings.InOutMode = DEVICE_SETTING[0]["InOutMode"]
            if device_Settings.InOutMode == True:
                IN_OUT_MODE = 2
        print(f"### Reloaded setting.", datetime.now())
        self.finished.emit()

class FailedDataController(QObject):
    finished = pyqtSignal()
    progress = pyqtSignal(str)
    def SyncFailedData(self):
        self.appCtrl = AppController()
        self.failed_count = self.appCtrl.Sync_User_Data_Failed()
        print(f"### Synced failed data: {self.failed_count}", datetime.now())
        self.finished.emit()

class SoundController(QObject):
    finished = pyqtSignal()
    progress = pyqtSignal(str)
    def openDoor(self):
        self.finished.emit()

class Camera(QObject):
    finished = pyqtSignal()
    progress = pyqtSignal(np.ndarray)
    running = True

    def run(self):
        if 'linux' in plform:
            self.camera = cv2.VideoCapture(CAMERA_INDEX)
        else:
            self.camera = cv2.VideoCapture(CAMERA_INDEX, cv2.CAP_DSHOW)
        self.camera.set(cv2.CAP_PROP_FRAME_WIDTH, FRAME_WIDTH)
        self.camera.set(cv2.CAP_PROP_FRAME_HEIGHT, FRAME_HEIGHT)
        self.camera.set(cv2.CAP_PROP_BUFFERSIZE, 2)
        self.mirror = True
        self.scale = 45
        while self.running:
            _, frame = self.camera.read()
            if _:
                # Rotate frame 180 degrees
                frame = cv2.rotate(frame, cv2.ROTATE_180)
                #if self.mirror:
                #    frame = cv2.flip(frame, 1)

                # #get the webcam size
                # height, width, channels = frame.shape
                # #prepare the crop
                # centerX,centerY=int(height/2),int(width/2)
                # radiusX,radiusY= int(self.scale*height/100),int(self.scale*width/100)
                # minX,maxX=centerX-radiusX,centerX+radiusX
                # minY,maxY=centerY-radiusY,centerY+radiusY
                # cropped = frame[minX:maxX, minY:maxY]
                # resized_cropped = cv2.resize(cropped, (width, height)) 
                
                #self.progress.emit(resized_cropped)
                self.progress.emit(frame)
            
        self.camera.release()
        self.finished.emit()

class EmployeeController():
    def Load_Employee_List(self):
        employeeList = []
        appCtrl = AppController()
        try:
            conn = pymssql.connect(server=device_Settings.Server, user=device_Settings.Username, password=device_Settings.Password, database=device_Settings.Database, login_timeout=device_Settings.DatabaseTimeout, timeout=device_Settings.DatabaseTimeout)
            # Load employee list from HR Database
            cursor = conn.cursor(as_dict=True)
            cursor.execute(QUERY_GET_EMPLOYEE_LIST)
            for item in cursor:
                employeeItem = Employee()
                employeeItem.EmployeeCode = item["EmployeeCode"]
                employeeItem.EmployeeName = item["EmployeeName"]
                employeeItem.NickName = item["NickName"]
                employeeItem.DateOfBirth = item["DateOfBirth"]
                employeeItem.Position = item["Position"]
                employeeItem.Department = item["Department"]
                employeeList.append(employeeItem)

            try:
                # Load accepted list from ESD Database
                cursor.execute(QUERY_GET_ESD_ACCESS_LIST)
                for item in cursor:
                    employeeItem = Employee()
                    employeeItem.EmployeeCode = item["id_card"]
                    employeeItem.EmployeeName = item["name"]
                    employeeItem.NickName = item["name"]
                    employeeItem.Position = "Outside"
                    employeeItem.Department = "Outside"
                    employeeList.append(employeeItem)
            except:
                pass    
            cursor.close()
            conn.close()
            print("Loaded Employee from database.")
            appCtrl.WriteToJsonFile(employeeList, EMPLOYEE_FILE_PATH)
        except Exception as ex:
            print(ex)
            print("Loaded Employee from local file.")
            with open(EMPLOYEE_FILE_PATH, "r") as f:
                data = json.load(f)
                for item in data:
                    employeeList.append(item)
        return employeeList
    

class ESDController(QObject):
    is_running = True
    finished = pyqtSignal(bool)

    def __init__(self):
        QObject.__init__(self)
        self.__user_list = EmployeeController().Load_Employee_List()
        self.__testing = False
        self._test_result = None
        self._test_duration = 0

    def run(self):
        while (self.is_running):
            try:
                tm_start = datetime.now()
                cur = 0
                while self.__testing:
                    self._test_duration = round((datetime.now() - tm_start).total_seconds(), 2)
                    # read test result
                    lfoot = nano.read_left_foot()
                    rfoot = nano.read_right_foot()
                    if lfoot and rfoot:
                        self._test_result = True
                        break
                    # test is timed out
                    elif self._test_duration > self.__timeout:
                        self._test_result = False
                        break
                
                if self._test_result is not None:
                    # Save ESD record
                    appCtrl = AppController()
                    appCtrl.InsertToESD(
                        self.__user_code,
                        self.__user_full_name,
                        self.__user_test_type,
                        self._test_duration,
                        "passed" if self._test_result else "failed")
                    self.finished.emit(self._test_result)
                    self.end_test()
            except:
                pass

    def authorize_user(self, code):
        return next(
            (user for user in self.__user_list if user.EmployeeCode == code),
             None
        )

    def clear_result(self):
        self._test_result = None
        self._test_duration = 0

    def is_testing(self):
        return self.__testing

    def begin_test(self, code, fullname, type, timeout=7):
        print("Begin test")
        self.clear_result()
        self.__user_code = code
        self.__user_full_name = fullname
        self.__user_test_type = type
        self.__timeout = timeout
        self.__testing = True
        nano.begin_test()

    def end_test(self):
        print("End test")
        self.clear_result()
        self.__testing = False
        

# Initializing Logger
info_log = AppController.SetupLog('info', DIR_NAME + '/logs/info.log', logging.INFO)
error_log = AppController.SetupLog('error', DIR_NAME + '/logs/error.log', logging.ERROR)

# Innitialize and declare FSDK
print("Initializing FSDK... ", end='')
FSDK.ActivateLibrary(LICENSE_KEY)
FSDK.Initialize()
print("OK\nLicense info:", FSDK.GetLicenseInfo())

# Set parameters for FSDK
FSDK.SetFaceDetectionParameters(True, True, 512)
FSDK.SetFaceDetectionThreshold(5)
err = FSDK.SetParameters(f"FaceDetectionModel={FD_MARKS_FILE_PATH};TrimFacesWithUncertainFacialFeatures=false")
print(err)

# Load face list form server or local data file
face_pro = FaceProccess()
FACE_LIST = face_pro.Load_Face_List()
print(f"### Count of Face List: {len(FACE_LIST)}")
#print(type(FACE_LIST[0]["Template"]))

# Load device setting of this machine
DEVICE_SETTING = face_pro.Load_Device_Setting()
if len(DEVICE_SETTING) > 0:
    #print(DEVICE_SETTING)
    device_Settings.MachineName = DEVICE_SETTING[0]["MachineName"]
    device_Settings.MachineType = DEVICE_SETTING[0]["MachineType"]
    device_Settings.Location = DEVICE_SETTING[0]["Location"]
    device_Settings.LinkToUpdate = DEVICE_SETTING[0]["LinkToUpdate"]
    device_Settings.NeedToUpdate = DEVICE_SETTING[0]["NeedToUpdate"]
    device_Settings.AllowFaceMask = DEVICE_SETTING[0]["AllowFaceMask"]
    device_Settings.AllowGroup = DEVICE_SETTING[0]["AllowGroup"]
    device_Settings.AdminUsers = DEVICE_SETTING[0]["AdminUsers"]
    device_Settings.DatabaseTimeout = DEVICE_SETTING[0]["DatabaseTimeout"]
    device_Settings.DoorTimeout = DEVICE_SETTING[0]["DoorTimeout"]
    device_Settings.Server = DEVICE_SETTING[0]["Server"]
    device_Settings.Database = DEVICE_SETTING[0]["Database"]
    device_Settings.Username = DEVICE_SETTING[0]["Username"]
    device_Settings.Password = DEVICE_SETTING[0]["Password"]
    device_Settings.UseEmoji = DEVICE_SETTING[0]["UseEmoji"]
    device_Settings.SmilePassed = DEVICE_SETTING[0]["SmilePassed"]
    device_Settings.SoftwareVersion = DEVICE_SETTING[0]["SoftwareVersion"]
    device_Settings.InOutMode = DEVICE_SETTING[0]["InOutMode"]
    if device_Settings.InOutMode == True:
        IN_OUT_MODE = 2


esd = ESDController()

EMBEDDED_PORT = "/dev/ttyUSB0"
GATE_DURATION = device_Settings.DoorTimeout / 1000
print("Initialize nano")
nano = Nano(EMBEDDED_PORT)
print("Nano connected")