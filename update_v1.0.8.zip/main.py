#!/usr/bin/env python3

from __future__ import print_function
from re import X
import sys, os, logging
from fsdk import FSDK
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import QThread, QTimer
from PyQt5.QtGui import QPixmap, QImage
from PyQt5.QtCore import Qt
from datetime import datetime
import serial
import controller
import time

# Main setting
TIME_RELOAD_SETTING = 30 * 60 * 1000
TIME_RELOAD_FACE_LIST = 15 * 60 * 1000
TIME_CHECK_SOFTWARE_UPDATE = 60 * 1000
TIME_TO_SYNC_DATA_FAILED = 30 * 60 * 1000
TIME_RELOAD_CHECK_LIST = 30 * 60 * 1000

ESD_SCANNING_IMAGE_PATH = os.path.join(controller.DIR_NAME, "images", "ESD_scanning.png")
ESD_TESTING_IMAGE_PATH = os.path.join(controller.DIR_NAME, "images", "ESD_testing.png")
ESD_PASSED_IMAGE_PATH = os.path.join(controller.DIR_NAME, "images", "ESD_passed.png")
ESD_FAILED_IMAGE_PATH = os.path.join(controller.DIR_NAME, "images", "ESD_failed.png")

class Ui_Recognize(object):
    displayTime = datetime.now()
    fontsizeDisplayName = 20
    fontsizeDisplayTime = 50
    fontsizeDisplayDate = 30
    fontsizeDisplayMessage = 30

    # fontsizeDisplayName = 15
    # fontsizeDisplayTime = 25
    # fontsizeDisplayDate = 11
    # fontsizeDisplayMessage = 20
    def setupUi(self, Recognize):
        Recognize.setObjectName("Recognize")
        Recognize.resize(1280, 800)
        Recognize.setStyleSheet(f"QWidget#Recognize {{border-image:url('{controller.DIR_NAME}/images/bg-image.png') 0 0 0 0 stretch stretch;}}")
        #Recognize.setWindowFlag(Qt.FramelessWindowHint)
        self.centralwidget = QtWidgets.QWidget(Recognize)
        self.centralwidget.setObjectName("centralwidget")
        self.graphicsView = QtWidgets.QGraphicsView(self.centralwidget)
        self.graphicsView.setGeometry(QtCore.QRect(7, 90, 780, 590))
        self.graphicsView.setObjectName("graphicsView")
        self.graphicsView.setStyleSheet("border:none;background:transparent;")
        self.lblESDResult = QtWidgets.QLabel(self.centralwidget)
        self.lblESDResult.setGeometry(QtCore.QRect(795, 570, 470, 100))
        self.lblESDResult.setObjectName("lblESDResult")
        self.lblESDResult.setAlignment(QtCore.Qt.AlignHCenter|QtCore.Qt.AlignVCenter)
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblTime = QtWidgets.QLabel(self.centralwidget)
        self.lblTime.setGeometry(QtCore.QRect(810, 150, 460, 60))
        font = QtGui.QFont()
        font.setPointSize(self.fontsizeDisplayTime)
        font.setBold(True)
        font.setWeight(75)
        self.lblTime.setFont(font)
        self.lblTime.setAlignment(QtCore.Qt.AlignCenter)
        self.lblTime.setObjectName("lblTime")
        self.lblStation = QtWidgets.QLabel(self.centralwidget)
        self.lblStation.setObjectName("lblStation")
        self.lblStation.setText(controller.device_Settings.Location.replace('-', ' '))
        self.lblStation.setGeometry(QtCore.QRect(792, 280, 475, 250))
        self.lblStation.setStyleSheet("color:darkblue;border:1px solid darkgray;background-color:lightgray;")
        font = QtGui.QFont()
        font.setPointSize(self.fontsizeDisplayTime)
        font.setWeight(75)
        self.lblStation.setFont(font)
        self.lblStation.setWordWrap(True)
        self.lblStation.setAlignment(QtCore.Qt.AlignCenter)
        self.graphicsView_Bottom = QtWidgets.QGraphicsView(self.centralwidget)
        self.graphicsView_Bottom.setGeometry(QtCore.QRect(0, 480, 1024, 120))
        self.graphicsView_Bottom.setObjectName("graphicsView_Bottom")
        self.graphicsView_Bottom.setStyleSheet("background-color:transparent;border:none;")
        self.lblMessage = QtWidgets.QLabel(self.centralwidget)
        self.lblMessage.setGeometry(QtCore.QRect(10, 690, 800, 100))
        font = QtGui.QFont()
        font.setPointSize(self.fontsizeDisplayMessage)
        font.setStrikeOut(False)
        font.setKerning(True)
        self.lblMessage.setFont(font)
        self.lblMessage.setAlignment(QtCore.Qt.AlignHCenter|QtCore.Qt.AlignVCenter)
        self.lblMessage.setWordWrap(True)
        self.lblMessage.setObjectName("lblMessage")
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(10, 520, 111, 45))
        font = QtGui.QFont()
        font.setPointSize(self.fontsizeDisplayName)
        self.label_4.setFont(font)
        self.label_4.setObjectName("label_4")
        self.label_4.setStyleSheet("background-color:transparent;")
        self.lblCode = QtWidgets.QLabel(self.centralwidget)
        self.lblCode.setGeometry(QtCore.QRect(112, 520, 211, 45))
        font = QtGui.QFont()
        font.setPointSize(self.fontsizeDisplayName)
        font.setBold(True)
        font.setWeight(75)
        self.lblCode.setFont(font)
        self.lblCode.setObjectName("lblCode")
        self.lblCode.setStyleSheet("background-color:transparent;")
        self.label_6 = QtWidgets.QLabel(self.centralwidget)
        self.label_6.setGeometry(QtCore.QRect(315, 520, 131, 45))
        font = QtGui.QFont()
        font.setPointSize(self.fontsizeDisplayName)
        self.label_6.setFont(font)
        self.label_6.setObjectName("label_6")
        self.label_6.setStyleSheet("background-color:transparent;")
        self.lblName = QtWidgets.QLabel(self.centralwidget)
        self.lblName.setGeometry(QtCore.QRect(430, 520, 581, 45))
        font = QtGui.QFont()
        font.setPointSize(self.fontsizeDisplayName)
        font.setBold(True)
        font.setWeight(75)
        self.lblName.setFont(font)
        self.lblName.setObjectName("lblName")
        self.lblName.setStyleSheet("background-color:transparent;")
        self.lblDate = QtWidgets.QLabel(self.centralwidget)
        self.lblDate.setGeometry(QtCore.QRect(810, 90, 460, 60))
        font = QtGui.QFont()
        font.setPointSize(self.fontsizeDisplayDate)
        self.lblDate.setFont(font)
        self.lblDate.setAlignment(QtCore.Qt.AlignCenter)
        self.lblDate.setObjectName("lblDate")
        self.lblVersion = QtWidgets.QLabel(self.centralwidget)
        self.lblVersion.setGeometry(QtCore.QRect(1170, 770, 100, 20))
        self.lblVersion.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.lblVersion.setAlignment(QtCore.Qt.AlignRight|QtCore.Qt.AlignTrailing|QtCore.Qt.AlignVCenter)
        self.lblVersion.setObjectName("lblVersion")
        self.lblVersion.setStyleSheet("background-color:transparent;")
        self.edt_scan = QtWidgets.QLineEdit(self.centralwidget)
        self.edt_scan.setGeometry(QtCore.QRect(0,-50,50,10))
        self.edt_scan.returnPressed.connect(self.scanner_received)
        Recognize.setCentralWidget(self.centralwidget)

        self.retranslateUi(Recognize)
        QtCore.QMetaObject.connectSlotsByName(Recognize)

        #Event
        # self.pushButton.clicked.connect(self.closeApp)
        # self.face_pos = controller.FacePos()

        # Set timer to reload setting from DB
        self._change_timer_st = QTimer()
        self._change_timer_st.setInterval(TIME_RELOAD_SETTING)
        self._change_timer_st.timeout.connect(self.reload_Setting)
        self._change_timer_st.start()
        
        # Set timer to reload data from DB
        self._change_timer_fl = QTimer()
        self._change_timer_fl.setInterval(TIME_RELOAD_FACE_LIST)
        self._change_timer_fl.timeout.connect(self.reload_FaceList)
        self._change_timer_fl.start()

        # Set timer to update new software version
        self._change_timer_su = QTimer()
        self._change_timer_su.setInterval(TIME_CHECK_SOFTWARE_UPDATE)
        self._change_timer_su.timeout.connect(self.update_Version)
        self._change_timer_su.start()

        # Set timer with interval 1 second
        self._change_timer_cs = QTimer()
        self._change_timer_cs.setInterval(1000)
        self._change_timer_cs.timeout.connect(self.count_SomeThing)
        self._change_timer_cs.start()

        # Set timer to sync failed data
        self._change_timer_sync = QTimer()
        self._change_timer_sync.setInterval(TIME_TO_SYNC_DATA_FAILED)
        self._change_timer_sync.timeout.connect(self.sync_FailedData)
        self._change_timer_sync.start()

        # Set timer to close the door
        self._change_timer_door = QTimer()
        self._change_timer_door.setInterval(controller.device_Settings.DoorTimeout)
        self._change_timer_door.setSingleShot(True)
        self._change_timer_door.timeout.connect(self.close_Door)

        # Set timer to idle state of application
        self._change_timer_idle = QTimer()
        self._change_timer_idle.setInterval(3000)
        self._change_timer_idle.timeout.connect(self.reset_Display)
        self._change_timer_idle.start()

        # Set timer to update new HR check data list
        self._change_timer_check = QTimer()
        self._change_timer_check.setInterval(TIME_RELOAD_CHECK_LIST)
        self._change_timer_check.timeout.connect(self.sync_CheckList)
        self._change_timer_check.start()

        ### Run the camera on another thread
        # Create a QThread object
        self.thread = QThread()
        self.capture = controller.Camera()
        self.capture.moveToThread(self.thread)
        self.thread.started.connect(self.capture.run)
        self.thread.finished.connect(self.thread.quit)
        self.capture.progress.connect(self.stream)
        self.thread.start()

        self.thread1 = QThread()
        self.facesearch = controller.FaceSearch()
        self.facesearch.moveToThread(self.thread1)
        self.thread1.started.connect(self.facesearch.run)
        self.thread1.finished.connect(self.thread1.quit)
        self.facesearch.progress.connect(self.display_Infomation)
        self.thread1.start()

        self.thread_esd = QThread()
        controller.esd.moveToThread(self.thread_esd)
        self.thread_esd.started.connect(controller.esd.run)
        self.thread_esd.finished.connect(self.thread_esd.quit)
        self.thread_esd.start()
        controller.esd.finished.connect(self.test_esd_finished)

        self.reset_Display()

    def stream(self, frame):
        height, width, channel = frame.shape
        #print(f"{width} - {height} - {channel}")
        qimage = QImage(frame.data, width, height, channel*width, QImage.Format_RGB888).rgbSwapped()
        pixmap = QPixmap(qimage)
        item = QtWidgets.QGraphicsPixmapItem(pixmap.scaled(self.graphicsView.size(), QtCore.Qt.KeepAspectRatio))
        scene = QtWidgets.QGraphicsScene()
        scene.addItem(item)
        gsize = self.graphicsView.contentsRect()
        self.graphicsView.setSceneRect(0, 0, gsize.width(), gsize.height())
        self.graphicsView.setScene(scene)
        self.graphicsView.fitInView(scene.itemsBoundingRect(), QtCore.Qt.KeepAspectRatio)

        self.facesearch.send_frame(frame)
        #self.drawFaceDetect()

    def display_Infomation(self, strResult):
        print(strResult)
        if not controller.esd.is_testing():
            arrResult = strResult.split('-')
            print(arrResult)
            self.test_esd(arrResult[0], 'face_id')

    def reset_Display(self):
        if not controller.esd.is_testing():
            self.set_message("Vui lòng nhận diện gương mặt\nhoặc quét mã số!")
            self.set_label_image(self.lblESDResult, ESD_SCANNING_IMAGE_PATH)
        # else:
        #     self._change_timer_idle.start()

    def reload_Setting(self):
        print(f"### Begin reload setting....", datetime.now())
        self.threadst = QThread()
        self.filestctrl = controller.SettingFileController()
        self.filestctrl.moveToThread(self.threadst)
        self.filestctrl.finished.connect(self.threadst.quit)
        self.threadst.started.connect(self.filestctrl.ReloadSettingFile)
        self.threadst.start()

    def reload_FaceList(self):
        print(f"### Begin reload data: {len(controller.FACE_LIST)}", datetime.now())
        self.threadnew = QThread()
        self.filectrl = controller.DataFileController()
        self.filectrl.moveToThread(self.threadnew)
        self.filectrl.finished.connect(self.threadnew.quit)
        self.threadnew.started.connect(self.filectrl.ReloadDataFile)
        self.threadnew.start()

    def sync_FailedData(self):
        print(f"### Begin sync failed data")
        self.threadsync = QThread()
        self.failedctrl = controller.FailedDataController()
        self.failedctrl.moveToThread(self.threadsync)
        self.failedctrl.finished.connect(self.threadsync.quit)
        self.threadsync.started.connect(self.failedctrl.SyncFailedData)
        self.threadsync.start()

    def sync_CheckList(self):
        print(f"### Begin sync check data HR")
        self.threadcheck = QThread()
        self.hrdatactrl = controller.HRDataController()
        self.hrdatactrl.moveToThread(self.threadcheck)
        self.hrdatactrl.finished.connect(self.threadcheck.quit)
        self.threadcheck.started.connect(self.hrdatactrl.SyncCheckList)
        self.threadcheck.start()

    def update_Version(self):
        self.appCtrl = controller.AppController()
        self.is_updated = self.appCtrl.UpdateSoftware()
        print("Updated version: " + str(self.is_updated))
        if self.is_updated == True:
            os.system(f"chmod 777 ./main.py")
            time.sleep(1)
            os.system(f"reboot")
            print("Restarting....")

    def count_SomeThing(self):
        # Display current time
        now = datetime.now()
        self.lblDate.setText(now.strftime("%A, %d %b, %Y"))
        self.current_time = now.strftime("%H:%M:%S")
        self.lblTime.setText(self.current_time)
        #self.appCrtl = controller.AppController()
        # Always focus on edit line to receive keyboard input
        self.edt_scan.setFocus()

    def open_Door(self):
        controller.nano.trigger_gate(controller.GATE_DURATION)
        # if self._change_timer_door.isActive() == False:
        #     self.threadsound = QThread()
        #     self.soundctrl = controller.SoundController()
        #     self.soundctrl.moveToThread(self.threadsound)
        #     self.soundctrl.finished.connect(self.threadsound.quit)
        #     self.threadsound.started.connect(self.soundctrl.openDoor)
        #     self.threadsound.start()
        
        # if self._change_timer_door.isActive() == False:
        #     print("Openning the door")
        #     self._change_timer_door.start()

        #     # if self._change_timer_door.isActive():
        #     #     self._change_timer_door.stop()
        #     #     self._change_timer_door.start()
        #     # else:
        #     #     self._change_timer_door.start()
                
        #     # serNano.write(str.encode("ONDOOR"))
        #     # data = serNano.readline().decode().strip()
        #     # print(data)
        #     # if data == "OpenedDOOR":
        #     #     return True
        #     # return False

    def close_Door(self):
        print("Closing the door")
        self._change_timer_door.stop()

        # serNano.write(str.encode("OFFDOOR"))
        # data = serNano.readline().decode().strip()
        # if data == "ClosedDOOR":
        #     return True
        # return False

    def set_message(self, text, color=Qt.darkBlue):
        color_effect = QtWidgets.QGraphicsColorizeEffect()
        color_effect.setColor(color)
        self.lblMessage.setGraphicsEffect(color_effect)
        self.lblMessage.setText(text)

    def set_label_image(self, label, image):
        pixmap = QPixmap(image)
        rs_pixmap = pixmap.scaled(label.size(), QtCore.Qt.KeepAspectRatio)
        label.setPixmap(rs_pixmap)

    def test_esd(self, code, type, force=True):
        if force:
            controller.esd.end_test()
        
        if not controller.esd.is_testing():
            user = controller.esd.authorize_user(code)
            if user is None:
                self.set_message(f"Unauthorized {code}", Qt.red)
                self.set_label_image(self.lblESDResult, ESD_FAILED_IMAGE_PATH)
            else:
                self.set_message(f"Xin chào, {user.EmployeeName}\nMời bạn test ESD")
                self.set_label_image(self.lblESDResult, ESD_TESTING_IMAGE_PATH)
                # Begin testing ESD and trigger test result signal
                controller.esd.begin_test(user.EmployeeCode, user.EmployeeName, type)

    def test_esd_finished(self, result):
        # Tested ESD passed
        if result:
            self.set_message("Chúc bạn một ngày làm việc vui vẻ!", Qt.darkGreen)
            self.set_label_image(self.lblESDResult, ESD_PASSED_IMAGE_PATH)
            self.open_Door()
        else:
            self.set_message("Test thất bại. Vui lòng thử lại!", Qt.red)
            self.set_label_image(self.lblESDResult, ESD_FAILED_IMAGE_PATH)
        
        self._change_timer_idle.start()

    def scanner_received(self):
        text = self.edt_scan.text()
        if len(text) > 0:
            self.test_esd(text, 'barcode', force=True)
            self.edt_scan.setText("")
            self.edt_scan.setFocus()

    def retranslateUi(self, Recognize):
        _translate = QtCore.QCoreApplication.translate
        Recognize.setWindowTitle(_translate("Recognize", "Face Recognition Appication"))
        self.lblTime.setText(_translate("Recognize", "00:00:00"))
        self.lblMessage.setText(_translate("Recognize", ""))
        self.label_4.setText(_translate("Recognize", ""))
        self.lblCode.setText(_translate("Recognize", ""))
        self.label_6.setText(_translate("Recognize", ""))
        self.lblName.setText(_translate("Recognize", ""))
        self.lblDate.setText(_translate("Recognize", datetime.now().strftime("%A, %d %b, %Y")))
        self.lblVersion.setText(_translate("Recognize", controller.device_Settings.SoftwareVersion))

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    Recognize = QtWidgets.QMainWindow()
    ui = Ui_Recognize()
    ui.setupUi(Recognize)
    Recognize.showFullScreen()
    Recognize.show() 
    sys.exit(app.exec_())
